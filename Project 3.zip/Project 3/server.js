/* ============================================================
   server.js — Hospital System Server (Complete & Final)
   ============================================================ */
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const Database = require('better-sqlite3');
const QRCode = require('qrcode');
const crypto = require('crypto');
const path = require('path');
const os = require('os');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });
const db = new Database(path.join(__dirname, 'hospital.db'));

app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

/* ============================================================
   DATABASE SCHEMA
   ============================================================ */
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA synchronous = NORMAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS patients (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT DEFAULT '',
    consult TEXT DEFAULT '',
    doctor TEXT DEFAULT '',
    seq INTEGER NOT NULL,
    current_dept TEXT DEFAULT 'doctor',
    status TEXT DEFAULT 'waiting',
    route TEXT DEFAULT '[]',
    priority INTEGER DEFAULT 0,
    created_at INTEGER NOT NULL,
    called_at INTEGER,
    completed_at INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_patients_dept ON patients(current_dept, status);
  CREATE INDEX IF NOT EXISTS idx_patients_status ON patients(status);

  CREATE TABLE IF NOT EXISTS ledger (
    id TEXT PRIMARY KEY,
    cardId TEXT DEFAULT '',
    name TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    amount REAL DEFAULT 0,
    currency TEXT DEFAULT 'IQD',
    method TEXT DEFAULT '',
    time TEXT NOT NULL,
    org TEXT DEFAULT ''
  );
  CREATE INDEX IF NOT EXISTS idx_ledger_time ON ledger(time DESC);

  CREATE TABLE IF NOT EXISTS cards (
    cardId TEXT PRIMARY KEY,
    qrToken TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    phone TEXT DEFAULT '',
    consult TEXT DEFAULT '',
    createdAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS vouchers (
    code TEXT PRIMARY KEY,
    value REAL NOT NULL,
    used INTEGER DEFAULT 0,
    createdAt TEXT NOT NULL,
    usedAt TEXT
  );

  CREATE TABLE IF NOT EXISTS departments (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    icon TEXT DEFAULT '🏥',
    class TEXT DEFAULT 'r-custom',
    sort_order INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS counters (
    id TEXT PRIMARY KEY,
    value INTEGER DEFAULT 0
  );
  INSERT OR IGNORE INTO counters (id, value) VALUES ('seq', 0);

  CREATE TABLE IF NOT EXISTS media (
    id TEXT PRIMARY KEY,
    patientName TEXT,
    type TEXT,
    imageUrl TEXT,
    timestamp INTEGER
  );
`);

/* ============================================================
   SEED DEFAULT DATA
   ============================================================ */
const defaultDepts = [
  { id: 'doctor',   name: 'الطبيب',         icon: '👨‍⚕️', class: 'r-doctor', sort_order: 1 },
  { id: 'pharmacy', name: 'الصيدلية',        icon: '💊',   class: 'r-pharma', sort_order: 2 },
  { id: 'lab',      name: 'المختبر',         icon: '🧪',   class: 'r-lab',    sort_order: 3 },
  { id: 'xray',     name: 'الأشعة والسونار', icon: '🩻',   class: 'r-xray',   sort_order: 4 }
];
const insertDept = db.prepare('INSERT OR IGNORE INTO departments (id, name, icon, class, sort_order) VALUES (?, ?, ?, ?, ?)');
defaultDepts.forEach(d => insertDept.run(d.id, d.name, d.icon, d.class, d.sort_order));

const defaultSettings = {
  ticketPrice: 5000, currency: 'IQD', orgName: 'مستشفى النور التخصصي',
  merchantQrLink: '', whatsappSender: '', voiceGender: 'female',
  voiceEnabled: 'on', autoPrint: 'off', callMode: 'screen',
  soundsFolder: 'sounds/', themeColor: '#00ff66', fontSize: 0, iconSize: 0
};
const upsertSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
Object.entries(defaultSettings).forEach(([k, v]) => upsertSetting.run(k, JSON.stringify(v)));

/* ============================================================
   HELPERS
   ============================================================ */
function getSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const out = {};
  rows.forEach(r => { try { out[r.key] = JSON.parse(r.value); } catch (e) { out[r.key] = r.value; } });
  return out;
}
function saveSettings(obj) {
  const stmt = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
  const tx = db.transaction(() => { Object.entries(obj).forEach(([k, v]) => stmt.run(k, JSON.stringify(v))); });
  tx();
}
function getDepartments() { return db.prepare('SELECT * FROM departments ORDER BY sort_order, name').all(); }
function toPatient(row) { return row ? { ...row, route: safeParse(row.route, []) } : null; }
function safeParse(s, fallback) { try { return JSON.parse(s); } catch (e) { return fallback; } }
function getPatient(id) { return toPatient(db.prepare('SELECT * FROM patients WHERE id = ?').get(id)); }
function getActivePatients() { return db.prepare("SELECT * FROM patients WHERE status != 'discharged' ORDER BY created_at DESC").all().map(toPatient); }
function getQueue(deptId) { return db.prepare("SELECT * FROM patients WHERE current_dept = ? AND status IN ('waiting','in_progress') ORDER BY priority DESC, created_at ASC").all(deptId).map(toPatient); }
function getLedger() { return db.prepare('SELECT * FROM ledger ORDER BY time DESC LIMIT 500').all(); }
function getCards() { return db.prepare('SELECT * FROM cards ORDER BY createdAt DESC').all(); }
function getVouchers() { return db.prepare('SELECT * FROM vouchers ORDER BY createdAt DESC').all(); }
function getMedia() { return db.prepare('SELECT * FROM media ORDER BY timestamp DESC LIMIT 100').all(); }

const DEPT_META = {
  doctor: { name: 'الطبيب', icon: '👨‍⚕️' }, pharmacy: { name: 'الصيدلية', icon: '💊' },
  lab: { name: 'المختبر', icon: '🧪' }, xray: { name: 'الأشعة والسونار', icon: '🩻' },
  reception: { name: 'الاستقبال', icon: '🏥' }, emergency: { name: 'الطوارئ', icon: '🚨' }
};

/* ============================================================
   WEBSOCKET & BROADCASTER
   ============================================================ */
const clients = new Map();

class DeltaBroadcaster {
  constructor(max = 100) { this.max = max; this.queue = []; this.running = false; this.stats = { sent: 0, dropped: 0 }; }
  send(payload, resolver) {
    this.queue.push({ payload, resolver });
    if (!this.running) this._start();
  }
  _start() {
    this.running = true;
    const interval = 1000 / this.max;
    const tick = () => {
      if (!this.queue.length) { this.running = false; return; }
      const { payload, resolver } = this.queue.shift();
      try {
        const json = JSON.stringify(payload);
        resolver().forEach(ws => { if (ws.readyState === 1) ws.send(json); });
        this.stats.sent++;
      } catch (e) { this.stats.dropped++; }
      setTimeout(tick, interval);
    };
    tick();
  }
}
const broadcaster = new DeltaBroadcaster(100);

function findSockets(target) {
  const result = [];
  const [kind, id] = target.split(':');
  clients.forEach((info, ws) => {
    if (kind === 'all') result.push(ws);
    else if (kind === 'role' && info.role === id) result.push(ws);
    else if (kind === 'dept' && info.role === 'dept' && info.deptId === id) result.push(ws);
    else if (kind === 'patient' && info.role === 'patient' && info.patientId === id) result.push(ws);
  });
  return result;
}
function broadcast(target, payload) { broadcaster.send(payload, () => findSockets(target)); }

function sendFullState(ws) {
  ws.send(JSON.stringify({
    type: 'init',
    patients: getActivePatients(),
    departments: getDepartments(),
    cards: getCards(),
    vouchers: getVouchers(),
    ledger: getLedger(),
    media: getMedia(),
    settings: getSettings()
  }));
}

wss.on('connection', (ws, req) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const role = url.searchParams.get('role') || 'unknown';
    const deptId = url.searchParams.get('dept');
    const patientId = url.searchParams.get('pid');

    clients.set(ws, { role, deptId, patientId });

    if (role === 'patient' && patientId) {
      ws.send(JSON.stringify({ type: 'init', patient: getPatient(patientId) }));
    } else if (role === 'dept' && deptId) {
      ws.send(JSON.stringify({ type: 'init', queue: getQueue(deptId), dept: deptId, deptMeta: DEPT_META[deptId] || {} }));
    } else {
      sendFullState(ws);
    }

    ws.on('message', raw => { try { handleMessage(JSON.parse(raw).type, JSON.parse(raw).data || {}, ws); } catch (e) {} });
    ws.on('close', () => clients.delete(ws));
    ws.on('error', () => clients.delete(ws));
  } catch (e) { try { ws.close(); } catch(e2) {} }
});

/* ============================================================
   MESSAGE HANDLER
   ============================================================ */
function handleMessage(type, data, ws) {
  try {
    switch (type) {
      case 'register': return doRegister(data, ws);
      case 'route': return doRoute(data, ws);
      case 'call': return doCall(data, ws);
      case 'payment': return doPayment(data, ws);
      case 'create_card': return doCreateCard(data, ws);
      case 'delete_card': return doDeleteCard(data);
      case 'clear_cards': return doClearCards();
      case 'generate_vouchers': return doGenerateVouchers(data);
      case 'clear_vouchers': return doClearVouchers();
      case 'clear_ledger': return doClearLedger();
      case 'update_settings': return doUpdateSettings(data);
      case 'add_department': return doAddDepartment(data);
      case 'delete_department': return doDeleteDepartment(data);
      case 'reset_all': return doResetAll();
      case 'request_sync': return sendFullState(ws);
      case 'discharge': return doDischarge(data);
      case 'send_to_pharmacy': return doSendToPharmacy(data);
      case 'transfer_request': return doTransferRequest(data);
      case 'upload_media': return doUploadMedia(data);
    }
  } catch (e) {
    if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'error', message: e.message }));
  }
}

/* ============================================================
   DO FUNCTIONS
   ============================================================ */
function doRegister(data, ws) {
  const name = String(data.name || '').trim();
  if (!name) throw new Error('اسم المريض مطلوب');
  db.prepare("UPDATE counters SET value = value + 1 WHERE id = 'seq'").run();
  const seq = db.prepare("SELECT value FROM counters WHERE id = 'seq'").get().value;
  const id = 'P' + Date.now().toString(36).toUpperCase() + crypto.randomBytes(2).toString('hex').toUpperCase();
  const route = [{ dept: 'الاستقبال', icon: '🏥', status: 'done', at: Date.now() }, { dept: 'الطبيب', icon: '👨‍⚕️', status: 'current', at: null }];
  db.prepare(`INSERT INTO patients (id, name, phone, consult, doctor, seq, current_dept, status, route, created_at) VALUES (?, ?, ?, ?, ?, ?, 'doctor', 'waiting', ?, ?)`).run(id, name, String(data.phone || ''), String(data.consult || ''), String(data.doctor || ''), seq, JSON.stringify(route), Date.now());
  const patient = getPatient(id);
  broadcast('role:reception', { type: 'patient_added', patient });
  broadcast('role:tv', { type: 'patient_added', patient });
  broadcast('dept:doctor', { type: 'patient_added', patient });
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'register_ok', patient }));
  return patient;
}

function doRoute(data, ws) {
  const row = db.prepare('SELECT * FROM patients WHERE id = ?').get(data.id);
  if (!row || row.current_dept === data.toDept) return;
  const route = safeParse(row.route, []);
  route.forEach(r => { if (r.status === 'current') r.status = 'done'; });
  const meta = DEPT_META[data.toDept] || { name: data.toDept, icon: '🏥' };
  route.push({ dept: meta.name, icon: meta.icon, status: 'current', at: Date.now() });
  db.prepare(`UPDATE patients SET current_dept = ?, route = ?, status = 'waiting', called_at = NULL WHERE id = ?`).run(data.toDept, JSON.stringify(route), data.id);
  const patient = getPatient(data.id);
  broadcast('role:reception', { type: 'patient_updated', patient });
  broadcast('role:tv', { type: 'patient_updated', patient });
  broadcast('dept:' + row.current_dept, { type: 'patient_removed', patientId: data.id });
  broadcast('dept:' + data.toDept, { type: 'patient_added', patient });
  broadcast('patient:' + data.id, { type: 'patient_update', patient });
}

function doCall(data, ws) {
  db.prepare("UPDATE patients SET status = 'in_progress', called_at = ? WHERE id = ?").run(Date.now(), data.id);
  const patient = getPatient(data.id);
  broadcast('dept:' + patient.current_dept, { type: 'patient_called', patient });
  broadcast('role:tv', { type: 'patient_called', patient });
  broadcast('patient:' + data.id, { type: 'called', patient });
}

function doDischarge(data, ws) {
  const row = db.prepare('SELECT * FROM patients WHERE id = ?').get(data.id);
  if (!row) return;
  db.prepare("UPDATE patients SET status = 'discharged', completed_at = ? WHERE id = ?").run(Date.now(), data.id);
  const patient = getPatient(data.id);
  broadcast('role:reception', { type: 'patient_updated', patient });
  broadcast('role:tv', { type: 'patient_removed', patientId: data.id });
  broadcast('dept:' + row.current_dept, { type: 'patient_removed', patientId: data.id });
  broadcast('patient:' + data.id, { type: 'discharged', patient });
}

function doPayment(data, ws) {
  if (/fail|0000/i.test(String(data.cardId || ''))) {
    if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'payment_fail', txRequestId: data.txRequestId, reason: 'declined' }));
    return;
  }
  if (data.method === 'voucher') {
    const v = db.prepare('SELECT * FROM vouchers WHERE code = ?').get(data.cardId);
    if (!v || v.used) {
      if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'payment_fail', txRequestId: data.txRequestId, reason: 'invalid_voucher' }));
      return;
    }
    db.prepare('UPDATE vouchers SET used = 1, usedAt = ? WHERE code = ?').run(new Date().toISOString(), data.cardId);
    broadcast('role:reception', { type: 'vouchers_updated', vouchers: getVouchers() });
  }
  const entry = { id: 'TX-' + Date.now(), cardId: String(data.cardId || ''), name: String(data.name || 'غير معروف'), phone: String(data.phone || ''), amount: Number(data.amount) || 0, currency: String(data.currency || 'IQD'), method: String(data.method || ''), time: new Date().toISOString(), org: String(getSettings().orgName || '') };
  db.prepare(`INSERT INTO ledger (id, cardId, name, phone, amount, currency, method, time, org) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(entry.id, entry.cardId, entry.name, entry.phone, entry.amount, entry.currency, entry.method, entry.time, entry.org);
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'payment_ok', txRequestId: data.txRequestId, entry }));
  broadcast('role:reception', { type: 'payment_ok', entry });
  broadcast('role:tv', { type: 'payment_added', entry });
  return entry;
}

function doCreateCard(data, ws) {
  const name = String(data.name || '').trim();
  if (!name) throw new Error('الاسم مطلوب');
  const cardId = 'PT-' + Date.now().toString(36).toUpperCase().slice(-6) + '-' + Math.floor(Math.random() * 9000 + 1000);
  const qrToken = 'QR-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const card = { cardId, qrToken, name, phone: String(data.phone || ''), consult: String(data.consult || ''), createdAt: new Date().toISOString() };
  db.prepare('INSERT INTO cards (cardId, qrToken, name, phone, consult, createdAt) VALUES (?, ?, ?, ?, ?, ?)').run(card.cardId, card.qrToken, card.name, card.phone, card.consult, card.createdAt);
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'card_added', card }));
  broadcast('role:reception', { type: 'card_added', card });
  return card;
}

function doDeleteCard(data) {
  db.prepare('DELETE FROM cards WHERE cardId = ?').run(data.cardId);
  broadcast('role:reception', { type: 'card_removed', cardId: data.cardId });
}

function doClearCards() {
  db.prepare('DELETE FROM cards').run();
  broadcast('role:reception', { type: 'cards_cleared' });
}

function doGenerateVouchers(data) {
  const count = Math.min(500, Math.max(1, Number(data.count) || 1));
  const value = Number(data.value) || 5000;
  const created = [];
  const stmt = db.prepare('INSERT INTO vouchers (code, value, used, createdAt) VALUES (?, ?, 0, ?)');
  const now = new Date().toISOString();
  const genCode = () => { const seg = () => crypto.randomBytes(3).toString('hex').slice(0, 4).toUpperCase(); return `NHC-${seg()}-${seg()}-${seg()}`; };
  const tx = db.transaction(() => {
    for (let i = 0; i < count; i++) {
      let code, attempts = 0;
      do { code = genCode(); attempts++; } while (db.prepare('SELECT 1 FROM vouchers WHERE code = ?').get(code) && attempts < 10);
      if (attempts >= 10) continue;
      stmt.run(code, value, now); created.push(code);
    }
  });
  tx();
  broadcast('role:reception', { type: 'vouchers_updated', vouchers: getVouchers() });
}

function doClearVouchers() {
  db.prepare('DELETE FROM vouchers').run();
  broadcast('role:reception', { type: 'vouchers_updated', vouchers: [] });
}

function doClearLedger() {
  db.prepare('DELETE FROM ledger').run();
  broadcast('role:reception', { type: 'ledger_cleared' });
}

function doUpdateSettings(data) {
  saveSettings(data);
  broadcast('role:reception', { type: 'settings_updated', settings: getSettings() });
  broadcast('role:tv', { type: 'settings_updated', settings: getSettings() });
}

function doAddDepartment(data) {
  const id = String(data.id || 'dept_' + Date.now().toString(36));
  const name = String(data.name || '').trim();
  if (!name) throw new Error('اسم القسم مطلوب');
  const maxOrder = db.prepare('SELECT MAX(sort_order) as m FROM departments').get().m || 0;
  db.prepare('INSERT OR IGNORE INTO departments (id, name, icon, class, sort_order) VALUES (?, ?, ?, ?, ?)').run(id, name, String(data.icon || '🏥'), String(data.class || 'r-custom'), maxOrder + 1);
  broadcast('all', { type: 'departments_updated', departments: getDepartments() });
}

function doDeleteDepartment(data) {
  db.prepare('DELETE FROM departments WHERE id = ?').run(data.id);
  broadcast('all', { type: 'departments_updated', departments: getDepartments() });
}

function doResetAll() {
  db.transaction(() => {
    db.prepare('DELETE FROM patients').run(); db.prepare('DELETE FROM ledger').run();
    db.prepare('DELETE FROM cards').run(); db.prepare('DELETE FROM vouchers').run();
    db.prepare('DELETE FROM media').run(); db.prepare("UPDATE counters SET value = 0 WHERE id = 'seq'").run();
  })();
  broadcast('all', { type: 'init', patients: [], departments: getDepartments(), cards: [], vouchers: [], ledger: [], media: [], settings: getSettings() });
}

/* ============================================================
   NEW FUNCTIONS (Doctor & Departments)
   ============================================================ */
function doSendToPharmacy(data) {
  broadcast('dept:pharmacy', { type: 'new_order', order: data });
  broadcast('role:reception', { type: 'new_order', order: data });
  console.log(`[PHARMACY] Order for ${data.patientName}`);
}

function doTransferRequest(data) {
  const deptMap = { 'مختبر': 'lab', 'أشعة': 'xray', 'سونار': 'xray', 'استشارة': 'doctor' };
  const target = 'dept:' + (deptMap[data.department] || 'lab');
  broadcast(target, { type: 'new_transfer', transfer: data });
  broadcast('role:reception', { type: 'new_transfer', transfer: data });
  console.log(`[TRANSFER] ${data.patientName} → ${data.department}`);
}

function doUploadMedia(data) {
  const id = 'MED-' + Date.now();
  const media = { ...data, id, timestamp: Date.now() };
  db.prepare('INSERT OR IGNORE INTO media (id, patientName, type, imageUrl, timestamp) VALUES (?, ?, ?, ?, ?)').run(media.id, media.patientName, media.type, media.imageUrl, media.timestamp);
  broadcast('dept:doctor', { type: 'media_added', media });
  console.log(`[MEDIA] ${data.type} for ${data.patientName}`);
}

/* ============================================================
   REST API & START
   ============================================================ */
app.get('/api/qr', async (req, res) => {
  try {
    const data = req.query.d || '';
    const size = Math.min(600, Math.max(80, Number(req.query.s) || 300));
    if (!data) return res.status(400).end('missing d');
    const buf = await QRCode.toBuffer(data, { width: size, margin: 2, errorCorrectionLevel: 'M', color: { dark: '#000000', light: '#ffffff' } });
    res.type('png').set('Cache-Control', 'public, max-age=3600').send(buf);
  } catch (e) { res.status(500).end(); }
});

app.get('/api/patients', (req, res) => res.json(getActivePatients()));
app.get('/api/queue/:dept', (req, res) => res.json(getQueue(req.params.dept)));
app.get('/api/departments', (req, res) => res.json(getDepartments()));
app.get('/api/stats', (req, res) => {
  res.json({ ...broadcaster.stats, patients: db.prepare("SELECT COUNT(*) as c FROM patients WHERE status != 'discharged'").get().c, total_patients: db.prepare('SELECT COUNT(*) as c FROM patients').get().c, cards: db.prepare('SELECT COUNT(*) as c FROM cards').get().c, vouchers: db.prepare('SELECT COUNT(*) as c FROM vouchers WHERE used = 0').get().c, ledger_total: db.prepare('SELECT SUM(amount) as s FROM ledger').get().s || 0 });
});

const PORT = process.env.PORT || 3000;
function getLocalIP() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) { if (net.family === 'IPv4' && !net.internal) return net.address; }
  }
  return 'localhost';
}

server.listen(PORT, '0.0.0.0', () => {
  const ip = getLocalIP();
  console.log('\n╔═══════════════════════════════════════════════╗');
  console.log('║   🏥  Hospital System  —  Ready               ║');
  console.log('╚═══════════════════════════════════════════════╝\n');
  console.log('📡 Network:  http://' + ip + ':' + PORT);
  console.log('🖥️  الاستقبال:   http://' + ip + ':' + PORT + '/reception.html');
  console.log('🖥️  الطبيب:      http://' + ip + ':' + PORT + '/doctor.html');
  console.log('🖥️  الصيدلية:    http://' + ip + ':' + PORT + '/pharmacy.html');
  console.log('🖥️  المختبر:     http://' + ip + ':' + PORT + '/lab.html');
  console.log('🖥️  الأشعة:      http://' + ip + ':' + PORT + '/radiology.html');
  console.log('🖥️  شاشة العرض:  http://' + ip + ':' + PORT + '/hospital_board.html');
  console.log('🔌 WebSocket: ws://' + ip + ':' + PORT + '/ws\n');
});

process.on('SIGINT', () => { try { db.close(); } catch (e) {} server.close(() => process.exit(0)); });
process.on('SIGTERM', () => { try { db.close(); } catch (e) {} server.close(() => process.exit(0)); });